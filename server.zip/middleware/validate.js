const Joi = require('joi');
const logger = require('../config/logger');

const validate = (schema) => (req, res, next) => {
    console.log("========== VALIDATE ==========");
    console.log("req.body =", JSON.stringify(req.body, null, 2));

    const validSchema = Joi.object(schema);

    const object = Object.keys(schema).reduce((obj, key) => {
        if (Object.prototype.hasOwnProperty.call(req, key)) {
            obj[key] = req[key];
        }
        return obj;
    }, {});

    console.log("object =", JSON.stringify(object, null, 2));

    const { value, error } = validSchema.validate(object, {
        abortEarly: false,
    });

    if (error) {
        console.log("JOI ERROR =", error.details);

        const errorMessage = error.details
            .map((details) => details.message)
            .join(", ");

        logger.warn(`Validation Error: ${errorMessage}`);

        return res.status(400).json({
            success: false,
            message: errorMessage,
            data: null,
        });
    }

    Object.assign(req, value);

    console.log("Validation Passed");
    console.log("==============================");

    return next();
};

module.exports = validate;